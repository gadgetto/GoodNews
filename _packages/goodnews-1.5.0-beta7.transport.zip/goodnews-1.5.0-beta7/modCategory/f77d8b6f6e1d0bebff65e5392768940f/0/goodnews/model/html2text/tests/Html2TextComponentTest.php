<?php

class Html2TextComponentTest extends \ComponentTests\ComponentTest {

	function getRoots() {
		return array(__DIR__ . "/..");
	}

}
