<?php
/**
 * @package goodnews
 */
class GoodNewsGroupMember extends xPDOSimpleObject {}
?>