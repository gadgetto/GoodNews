--------------------
Extra: GoodNews
--------------------
Author: bitego <office@bitego.com> (Martin Gartner, Franz Gallei)
--------------------
 
An integrated group and newsletter mailing system.

GoodNews is a powerful integrated group and newsletter mailing 
system for the content management framework MODX Revolution.

With GoodNews you can easily create mailings or newsletters 
and have them sent to your subscribers or internal MODX user 
groups automatically right from your MODX back-end. GoodNews 
is built with a lot of passion for details, a polished interface 
and easy operation.

The sending process of GoodNews is lightning 
fast due to its underlying multithreaded sending system.

GoodNews has built in bounce handling for scanning bounced email
messages and to automatically perform some actions on subscribers 
based on bounce counters.

Reqirements:

- MODX 2.2.1 or later
- PHP 5.3 or later
- Cron
- PHP Imap Extension (for automatic bounce handling)
- pThumb add-on (for automatic image resizing)

Feel free to suggest ideas/improvements/bugs on our website:

http://www.bitego.com/extras/goodnews/goodnews-support.html

