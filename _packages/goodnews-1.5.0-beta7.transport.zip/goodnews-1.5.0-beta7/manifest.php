<?php return array (
  'manifest-version' => '1.1',
  'manifest-attributes' => 
  array (
    'license' => 'GNU GENERAL PUBLIC LICENSE
   Version 2, June 1991
--------------------------

Copyright (C) 1989, 1991 Free Software Foundation, Inc.
59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

Everyone is permitted to copy and distribute verbatim copies
of this license document, but changing it is not allowed.

Preamble
--------

  The licenses for most software are designed to take away your
freedom to share and change it.  By contrast, the GNU General Public
License is intended to guarantee your freedom to share and change free
software--to make sure the software is free for all its users.  This
General Public License applies to most of the Free Software
Foundation\'s software and to any other program whose authors commit to
using it.  (Some other Free Software Foundation software is covered by
the GNU Library General Public License instead.)  You can apply it to
your programs, too.

  When we speak of free software, we are referring to freedom, not
price.  Our General Public Licenses are designed to make sure that you
have the freedom to distribute copies of free software (and charge for
this service if you wish), that you receive source code or can get it
if you want it, that you can change the software or use pieces of it
in new free programs; and that you know you can do these things.

  To protect your rights, we need to make restrictions that forbid
anyone to deny you these rights or to ask you to surrender the rights.
These restrictions translate to certain responsibilities for you if you
distribute copies of the software, or if you modify it.

  For example, if you distribute copies of such a program, whether
gratis or for a fee, you must give the recipients all the rights that
you have.  You must make sure that they, too, receive or can get the
source code.  And you must show them these terms so they know their
rights.

  We protect your rights with two steps: (1) copyright the software, and
(2) offer you this license which gives you legal permission to copy,
distribute and/or modify the software.

  Also, for each author\'s protection and ours, we want to make certain
that everyone understands that there is no warranty for this free
software.  If the software is modified by someone else and passed on, we
want its recipients to know that what they have is not the original, so
that any problems introduced by others will not reflect on the original
authors\' reputations.

  Finally, any free program is threatened constantly by software
patents.  We wish to avoid the danger that redistributors of a free
program will individually obtain patent licenses, in effect making the
program proprietary.  To prevent this, we have made it clear that any
patent must be licensed for everyone\'s free use or not licensed at all.

  The precise terms and conditions for copying, distribution and
modification follow.


GNU GENERAL PUBLIC LICENSE
TERMS AND CONDITIONS FOR COPYING, DISTRIBUTION AND MODIFICATION
---------------------------------------------------------------

  0. This License applies to any program or other work which contains
a notice placed by the copyright holder saying it may be distributed
under the terms of this General Public License.  The "Program", below,
refers to any such program or work, and a "work based on the Program"
means either the Program or any derivative work under copyright law:
that is to say, a work containing the Program or a portion of it,
either verbatim or with modifications and/or translated into another
language.  (Hereinafter, translation is included without limitation in
the term "modification".)  Each licensee is addressed as "you".

Activities other than copying, distribution and modification are not
covered by this License; they are outside its scope.  The act of
running the Program is not restricted, and the output from the Program
is covered only if its contents constitute a work based on the
Program (independent of having been made by running the Program).
Whether that is true depends on what the Program does.

  1. You may copy and distribute verbatim copies of the Program\'s
source code as you receive it, in any medium, provided that you
conspicuously and appropriately publish on each copy an appropriate
copyright notice and disclaimer of warranty; keep intact all the
notices that refer to this License and to the absence of any warranty;
and give any other recipients of the Program a copy of this License
along with the Program.

You may charge a fee for the physical act of transferring a copy, and
you may at your option offer warranty protection in exchange for a fee.

  2. You may modify your copy or copies of the Program or any portion
of it, thus forming a work based on the Program, and copy and
distribute such modifications or work under the terms of Section 1
above, provided that you also meet all of these conditions:

    a) You must cause the modified files to carry prominent notices
    stating that you changed the files and the date of any change.

    b) You must cause any work that you distribute or publish, that in
    whole or in part contains or is derived from the Program or any
    part thereof, to be licensed as a whole at no charge to all third
    parties under the terms of this License.

    c) If the modified program normally reads commands interactively
    when run, you must cause it, when started running for such
    interactive use in the most ordinary way, to print or display an
    announcement including an appropriate copyright notice and a
    notice that there is no warranty (or else, saying that you provide
    a warranty) and that users may redistribute the program under
    these conditions, and telling the user how to view a copy of this
    License.  (Exception: if the Program itself is interactive but
    does not normally print such an announcement, your work based on
    the Program is not required to print an announcement.)

These requirements apply to the modified work as a whole.  If
identifiable sections of that work are not derived from the Program,
and can be reasonably considered independent and separate works in
themselves, then this License, and its terms, do not apply to those
sections when you distribute them as separate works.  But when you
distribute the same sections as part of a whole which is a work based
on the Program, the distribution of the whole must be on the terms of
this License, whose permissions for other licensees extend to the
entire whole, and thus to each and every part regardless of who wrote it.

Thus, it is not the intent of this section to claim rights or contest
your rights to work written entirely by you; rather, the intent is to
exercise the right to control the distribution of derivative or
collective works based on the Program.

In addition, mere aggregation of another work not based on the Program
with the Program (or with a work based on the Program) on a volume of
a storage or distribution medium does not bring the other work under
the scope of this License.

  3. You may copy and distribute the Program (or a work based on it,
under Section 2) in object code or executable form under the terms of
Sections 1 and 2 above provided that you also do one of the following:

    a) Accompany it with the complete corresponding machine-readable
    source code, which must be distributed under the terms of Sections
    1 and 2 above on a medium customarily used for software interchange; or,

    b) Accompany it with a written offer, valid for at least three
    years, to give any third party, for a charge no more than your
    cost of physically performing source distribution, a complete
    machine-readable copy of the corresponding source code, to be
    distributed under the terms of Sections 1 and 2 above on a medium
    customarily used for software interchange; or,

    c) Accompany it with the information you received as to the offer
    to distribute corresponding source code.  (This alternative is
    allowed only for noncommercial distribution and only if you
    received the program in object code or executable form with such
    an offer, in accord with Subsection b above.)

The source code for a work means the preferred form of the work for
making modifications to it.  For an executable work, complete source
code means all the source code for all modules it contains, plus any
associated interface definition files, plus the scripts used to
control compilation and installation of the executable.  However, as a
special exception, the source code distributed need not include
anything that is normally distributed (in either source or binary
form) with the major components (compiler, kernel, and so on) of the
operating system on which the executable runs, unless that component
itself accompanies the executable.

If distribution of executable or object code is made by offering
access to copy from a designated place, then offering equivalent
access to copy the source code from the same place counts as
distribution of the source code, even though third parties are not
compelled to copy the source along with the object code.

  4. You may not copy, modify, sublicense, or distribute the Program
except as expressly provided under this License.  Any attempt
otherwise to copy, modify, sublicense or distribute the Program is
void, and will automatically terminate your rights under this License.
However, parties who have received copies, or rights, from you under
this License will not have their licenses terminated so long as such
parties remain in full compliance.

  5. You are not required to accept this License, since you have not
signed it.  However, nothing else grants you permission to modify or
distribute the Program or its derivative works.  These actions are
prohibited by law if you do not accept this License.  Therefore, by
modifying or distributing the Program (or any work based on the
Program), you indicate your acceptance of this License to do so, and
all its terms and conditions for copying, distributing or modifying
the Program or works based on it.

  6. Each time you redistribute the Program (or any work based on the
Program), the recipient automatically receives a license from the
original licensor to copy, distribute or modify the Program subject to
these terms and conditions.  You may not impose any further
restrictions on the recipients\' exercise of the rights granted herein.
You are not responsible for enforcing compliance by third parties to
this License.

  7. If, as a consequence of a court judgment or allegation of patent
infringement or for any other reason (not limited to patent issues),
conditions are imposed on you (whether by court order, agreement or
otherwise) that contradict the conditions of this License, they do not
excuse you from the conditions of this License.  If you cannot
distribute so as to satisfy simultaneously your obligations under this
License and any other pertinent obligations, then as a consequence you
may not distribute the Program at all.  For example, if a patent
license would not permit royalty-free redistribution of the Program by
all those who receive copies directly or indirectly through you, then
the only way you could satisfy both it and this License would be to
refrain entirely from distribution of the Program.

If any portion of this section is held invalid or unenforceable under
any particular circumstance, the balance of the section is intended to
apply and the section as a whole is intended to apply in other
circumstances.

It is not the purpose of this section to induce you to infringe any
patents or other property right claims or to contest validity of any
such claims; this section has the sole purpose of protecting the
integrity of the free software distribution system, which is
implemented by public license practices.  Many people have made
generous contributions to the wide range of software distributed
through that system in reliance on consistent application of that
system; it is up to the author/donor to decide if he or she is willing
to distribute software through any other system and a licensee cannot
impose that choice.

This section is intended to make thoroughly clear what is believed to
be a consequence of the rest of this License.

  8. If the distribution and/or use of the Program is restricted in
certain countries either by patents or by copyrighted interfaces, the
original copyright holder who places the Program under this License
may add an explicit geographical distribution limitation excluding
those countries, so that distribution is permitted only in or among
countries not thus excluded.  In such case, this License incorporates
the limitation as if written in the body of this License.

  9. The Free Software Foundation may publish revised and/or new versions
of the General Public License from time to time.  Such new versions will
be similar in spirit to the present version, but may differ in detail to
address new problems or concerns.

Each version is given a distinguishing version number.  If the Program
specifies a version number of this License which applies to it and "any
later version", you have the option of following the terms and conditions
either of that version or of any later version published by the Free
Software Foundation.  If the Program does not specify a version number of
this License, you may choose any version ever published by the Free Software
Foundation.

  10. If you wish to incorporate parts of the Program into other free
programs whose distribution conditions are different, write to the author
to ask for permission.  For software which is copyrighted by the Free
Software Foundation, write to the Free Software Foundation; we sometimes
make exceptions for this.  Our decision will be guided by the two goals
of preserving the free status of all derivatives of our free software and
of promoting the sharing and reuse of software generally.

NO WARRANTY
-----------

  11. BECAUSE THE PROGRAM IS LICENSED FREE OF CHARGE, THERE IS NO WARRANTY
FOR THE PROGRAM, TO THE EXTENT PERMITTED BY APPLICABLE LAW.  EXCEPT WHEN
OTHERWISE STATED IN WRITING THE COPYRIGHT HOLDERS AND/OR OTHER PARTIES
PROVIDE THE PROGRAM "AS IS" WITHOUT WARRANTY OF ANY KIND, EITHER EXPRESSED
OR IMPLIED, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF
MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.  THE ENTIRE RISK AS
TO THE QUALITY AND PERFORMANCE OF THE PROGRAM IS WITH YOU.  SHOULD THE
PROGRAM PROVE DEFECTIVE, YOU ASSUME THE COST OF ALL NECESSARY SERVICING,
REPAIR OR CORRECTION.

  12. IN NO EVENT UNLESS REQUIRED BY APPLICABLE LAW OR AGREED TO IN WRITING
WILL ANY COPYRIGHT HOLDER, OR ANY OTHER PARTY WHO MAY MODIFY AND/OR
REDISTRIBUTE THE PROGRAM AS PERMITTED ABOVE, BE LIABLE TO YOU FOR DAMAGES,
INCLUDING ANY GENERAL, SPECIAL, INCIDENTAL OR CONSEQUENTIAL DAMAGES ARISING
OUT OF THE USE OR INABILITY TO USE THE PROGRAM (INCLUDING BUT NOT LIMITED
TO LOSS OF DATA OR DATA BEING RENDERED INACCURATE OR LOSSES SUSTAINED BY
YOU OR THIRD PARTIES OR A FAILURE OF THE PROGRAM TO OPERATE WITH ANY OTHER
PROGRAMS), EVEN IF SUCH HOLDER OR OTHER PARTY HAS BEEN ADVISED OF THE
POSSIBILITY OF SUCH DAMAGES.

---------------------------
END OF TERMS AND CONDITIONS',
    'readme' => '--------------------
Extra: GoodNews
--------------------
Author: bitego <office@bitego.com> (Martin Gartner, Franz Gallei)
--------------------
 
An integrated group and newsletter mailing system.

GoodNews is a powerful integrated group and newsletter mailing 
system for the content management framework MODX Revolution.

With GoodNews you can easily create mailings or newsletters 
and have them sent to your subscribers or internal MODX user 
groups automatically right from your MODX back-end. GoodNews 
is built with a lot of passion for details, a polished interface 
and easy operation.

The sending process of GoodNews is lightning 
fast due to its underlying multithreaded sending system.

GoodNews has built in bounce handling for scanning bounced email
messages and to automatically perform some actions on subscribers 
based on bounce counters.

Reqirements:

- MODX 2.2.1 or later
- PHP 5.3 or later
- Cron
- PHP Imap Extension (for automatic bounce handling)
- pThumb add-on (for automatic image resizing)

Feel free to suggest ideas/improvements/bugs on our website:

http://www.bitego.com/extras/goodnews/goodnews-support.html

',
    'changelog' => 'Changelog for GoodNews

- enhanced automatic multipart mail generation (plain-text part of mail is now perfectly formatted and respects full mail body)
- refactored preinstalled sample newsletter templates for simplicity and clean design
- fixing a small bug in email template processing (sometimes closing </body></html> tags were cropped)
- fixed flickering in groups and categories grid on tabchange (caused by forced refresh)
- refactored all email-template chunks (for subscription, profile and reports) for simplicity and clean design
- finally fixing all collapse problems on grid refresh when rowExpander is enabled (thanks @Alroniks)
- fixed a problem where grid refresh doesn’t properly collapse expanded rows
- changed autorefresh and workerprocess-emergency-stop buttons from splitbutton to modern chebox toggle switches
- first changes for better MODX 3 compatibility
- added new GDPR fields (activatedon, ip_activated) to subscribers export
- better UI for auto-refresh button
- better UI/UX for emergency stop of worker processes
- remastered the initialization process
- implemented a flexible setup/initialization error handling
- added a CMP for error handling
- [#60] proper handling for "no GoodNews container available" situations
- proper handling for "access denied" situations
- fixed a PHP warning in full URL conversion class
- general GDPR compliance release (1st-step)!
- make automatic inlining of CSS a setting (Gmail now supports embedded CSS, which removes the need for inline CSS in Gmail)
- fixed user related placeholders for subscription/activation email templates (now all placeholders from user object are provided)
- [#63] refactored all sample resource documents for GDPR compliance + fresh and clean HTML5
- added sample Privacy Policy and terms and Conditions resources to installer
- [#61] extended subscription process to also log activation IP + timestamp (GDPR compliance)


GoodNews 1.4.8-pl (2017-02-16)
--------------------------------------------------
- [#39] added subscribers export feature
- refined subscribers grid display (more details, better differentiability)
- [#6] added bulk actions to susbcribers grid
- fixed a critical bug in subscriber authentication (as a result from a merge conflict)


GoodNews 1.4.7-pl2 (2017-12-13)
--------------------------------------------------
- fixed edit icon in grid row in Settings -> Container grid


GoodNews 1.4.7-pl (2017-12-12)
--------------------------------------------------
- added edit icon to grid row in Settings -> Container grid
- [#56] fixed broken chunksPath in goodnewssubscription.class.php
- fixed some typos in lexicons
- [#57] exlude mailto links from link manipulation (_fullURLs method)
- [#54] fixed typos in sample.GoodNewsSubscriptionBoxTpl Chunk
- [#53] fixed typo in requestlinks.class.php
- [#52] fixed typo in sample.GoodNewsContentCollectionRowTpl
- [#51] fixed typos in LOG_LEVEL_WARN constant
- send mail method now also respects mail port setting from MODX system settings
- removed path and TV resolvers from setup process
- fixed a problem in Registration/Subscription process where username wasn\'t checked before trying to create user
- added feature to use GoodNewsUpdateProfile Snippet for logged in MODX users (not only via sid URL param)


GoodNews 1.4.6-pl (2017-03-10)
--------------------------------------------------

- fixed a problem where Subscriber placeholders in newsletter templates were URL encoded before processing
- fixed a PHP warning: Undefined variable: base
- removed permission check for „Toggle send process“
- removed grid flickering (grid mask) when auto-refresh is activated
- fixed a problem where GoodNews groups which were assigned to MODX user groups couldn\'t be unassigned


GoodNews 1.4.5-pl (2017-02-19)
--------------------------------------------------

- exclude blocked MODX users from recipients collection
- fixed a problem in Subscription controller when &usernameField property is set
- [#43] complete rewrite of automatic full URL conversion (now respects #anchor links external links and protocol-relative URLs)
- fixed errors in package uninstall process
- refined Package installer and uninstaller to output more usefull informations
- added setup options to package installer to enable/disable installation of sample Resource documents
- added system setting to enable/disable automatic URL conversion in email body
- fixed "Created by" dropdown username display in mailing editor
- "Save" button in mailing editor has now MODX primary button color
- fixed a problem where selecting Collection rows didn\'t fire a resource form change ("Save" button wasn\'t activated)
- [#17] added newsletter send-log viewer and log-file export to CSV
- changed row expander icons for newsletter and subscribers grid to make it clear that rows can be expanded
- fixed issues with array fields in GoodNewsUpdateProfile snippet (fix by @Jako taken from Register snippet/Login package)
- removed superfluous default \'isset\' parameter from getProperty calls (fix by @Jako taken from Register snippet/Login package)
- fixed a very stupid and old bug in lock-file handling
- mail subjects are now converted to charset of mailing (contributed by @mindeffects)
- fixed a missing index log entry in cron.php
- fixed a problem (since MODX 2.5.2) in goodnews.class.php constructor when executed in CLI mode
- fixed issues with array fields in GoodNewsSubscription snippet (fix by @Jako taken from Register snippet/Login package)


GoodNews 1.4.2-pl (2016-10-29)
--------------------------------------------------
- fixed subscriber "Created on" problem (conflicting field names since MODX 1.5.x users have an explicit createdon field)
- fixed emptying cachepwd field when subscription is confirmed
- fixed sending activation email if activationEmail property is not set
- fixed a problem with detecting extended fields in form
- fixed Custom Resource Properties Resolver in GoodNews container installation (unsubscribeResource and profileResource properties)
- fixed template assignement for sample resources on package upgrade
- corrected poor thinking in registration-confirm resource


GoodNews 1.4.1-pl (2016-03-02)
--------------------------------------------------
- Added all missing custom validators from Login extra
- Added snippets, resources and chunks to allow full MODX user registration including newsletter subscription on a single page
- Even more refined subscription process
- Missing snippet params dont break Subscription, RequestLinks and ConfirmSubscription snippets any longer
- [#40] newsletter templates now have full access to all modUserProfile and GoodNewsSubscriberMeta fields as placeholders
- fixed a bug with tvs_below_content setting in Mailing editor
- [#3] send a status email to newsletter sender if mailing status changes
- renamed preinstalled Resource domcuments to prevent overwriting of existing
- preinstalled Resource documents aren\'t moved to tree root on package update (Installer)
- [#38] fixed a php warning in processhandler class

 
GoodNews 1.4.0-pl (2015-11-05)
--------------------------------------------------
- completely revised the Subscriber registration system (front-end)
- new professional system mail templates (activation, success, request links, etc.)
- fixed a few nasty bugs in Susbcriber registration
- [#22] enable subscription of users which already have an account in the MODX instance
- [#21] enable re-subscription of users with cancelled or forgotten subscriptions
- fixed security/privacy problems (now front-end forms will never tell if email addresses already exists)


GoodNews 1.3.9-pl (2015-10-23)
--------------------------------------------------
- improved robustness of mail processing
- fixed a nasty bug with lockfile handling + recipient status update
- fixed error messages in GoodNews installer while updating database schema (...field allready exists)
- added "public" field to Groups (same behaviour as in Categories)
- changed behaviour of "public" field for Categories and makes it possible to send newsletters to non-public Categories


GoodNews 1.3.8-pl (2015-09-13)
--------------------------------------------------
- fixed a bug in combining filters on Subscribers grid
- [#34] added Category filter to Subscribers grid
- added Activated filter to Subscribers grid
- added plugin version and icons to action-toolbar
- reordered newsletter grid context menu (now it should be more logical)
- removed/disabled Delete action (menu and button) from mailing when sending is in progress 
- added action buttons to newsletters grid
- [#35] fixed a problem with send counter when timed out mails are detected
- the Mail Summary field is now able to grow in it\'s height when text is entered
- small graphical fixes
- refined some lexicon strings


GoodNews 1.3.7-pl (2015-06-29)
--------------------------------------------------
- fixed a PHP warning in MODX error log
- added preset for Mandrill SMTP service settings
- added feature to let each container have it\'s own SMTP settings (overrides MODX system settings)
- added feature to let each container have it\'s own mail charset and mail encoding settings (overrides MODX system settings)


GoodNews 1.3.6-pl (2015-03-29)
--------------------------------------------------
- added French translation (thank\'s Julien Studer!)
- fixed missing english strings + small typo in lexicon
- fixed a bug when sorting the Subscribers grid by subscription date
- added indicator in mailing editor if mailing is in read-only mode (sending already started)
- fixed waring message when mailing resource is in read-only mode
- fixed some PHP warnings if collections field of mailing_meta is empty (happens for resources prior to version 1.3.0-pl)
- [#33] Integrate functionality to auto-detect images and convert physical image dimensions based on src or style attributes
- fixed a problem in ContentCollection snippet when using tplWrapper
- removed ContentCollectionSnippet output if collection is empty


GoodNews 1.3.5-pl (2014-12-10)
--------------------------------------------------
- added ability to click on newsletter title to edit the newsletter
- added a switch above Newsletters grid to quickly activate/deactivate send-processes
- [#32] Add back an indicator for displaying if sending processes are activated/deactivated in settings
- fixed a problem in System settings when Admin or Editor group names have leading or trailing spaces
- fixed a bug with slider value displays in GoodNews - System settings
- [#30] added indicator in GoodNews - System Checks for requirement of PHP versions > 5.3.0
- fixed a bug in resource rendering (this was a tricky one!)


GoodNews 1.3.4-pl (2014-12-03)
--------------------------------------------------
- fixed a problem where Resource Collections aren\'t restored correctly from database
- added container filter dropdown in Resource Collections grid (better user experience)
- removed grouping by container in Resource Collections grid
- added PHP 5.3 (or later) requirement to readme.txt
- again fixed another small bug in how cron security keys are checked :)
- fixed a problem where Resource Collections are empty on first load (no Collections array available in mailing_meta)


GoodNews 1.3.3-pl (2014-11-16)
--------------------------------------------------
- fixed an issue with checkboxes causing text-parsing problems when using the "required" validator
- [#5] Render warning message to GoodNews forms if Snippets are mis-configured
- fixed a few PHP warnings in goodnewssubscriptioncontroller.class.php
- when updating the subscription profile: update form fields with new values when reloadOnSuccess = false
- [#29] Frontend: groups checkboxes output is falsely rendered inside html form fieldset for each single group
- [#28] Frontend: Subscription snippet - crashes during validation if email field is empty
- improved username creation in Subscriber Importer (we now use the userid part of the email address)


GoodNews 1.3.2-pl (2014-11-01)
--------------------------------------------------
- [#27] Subscriber meta data not created for existing MODX users when using the "Import Update Feature"
- [#26] Editing a GoodNews Container - mailing templates category dropdown doesn\'t list all Categories
- small lexicon adjustments to better match MODX 2.3


GoodNews 1.3.1-pl (2014-10-28)
--------------------------------------------------
- [#25] Extend Subscriber Importer to enable "Update" of existing subscribers
- fixed a bug in Import console window (console window is now destroyed after closing)
- fixed a bug in German lexicon file (missing semicolon could lead to white page -> sorry for this!)
- GoodNews management interface now takes account of MODX manager date and time format settings
- deleted mailing editor users are now recognized and it\'s id is now shown instead empty string


GoodNews 1.3.0-pl (2014-10-13)
--------------------------------------------------
- [#15] new feature: Content collector


GoodNews 1.2.2-pl (2014-09-15)
--------------------------------------------------
- some small cosmetical changes in forms


GoodNews 1.2.1-pl (2014-09-14)
--------------------------------------------------
- adapted searchfilter fields + reset buttons above grids to match MODX 2.3 style
- added debug-mode status to System Checks table
- [#24] fixed rendering of grids in tab panels (resizing problem)
- fixed some PHP warnings in getgroupcatnodes.class.php
- fixed some IMAP warnings in bounce handler


GoodNews 1.2.0-pl (2014-09-09)
--------------------------------------------------
- [#23] fixed PHP memory limit problem on server with huge list of subscribers
- complete rewrite on how the sending engine handles recipients!
- huge performance increase and much better memory management for sending engine
- many other small memory and performance related enhancements
- added sending error counter to mailing grid


GoodNews 1.1.7-pl (2014-09-02)
--------------------------------------------------
- [#20] new feature to manually disable multiprocessing
- fixed another small bug in how cron security keys are checked :)
- added error handler loading to cron.php and cron.worker.php (needed since MODX 2.3+)


GoodNews 1.1.6-pl (2014-08-24)
--------------------------------------------------
- [#19] new feature to request secure links via email
- security fix for subscribers getlist processor
- fixed wrong width of "Created By" combo field in mailing editor
- fileuploadfield extension only needs to be loaded in MODX < 2.3 (natively supported in MODX >= 2.3)
- removed custom form field description styles - using default MODx style
- added feature to manually reset bounce counters of a subscriber
- Cosmetical changes to Groups/Categories tree
- added row-expander to subscribers grid for detailed informations and save grid space
- moved  subscriber id to row epander
- moved  subscriber ip address to row epander
- small corrections/changes in lexicon strings


GoodNews 1.1.5-pl (2014-07-25)
--------------------------------------------------

- additional CSS fixes (because of last minute changes in Revo 2.3)
- small corrections/changes in lexicon strings
- changed Auto-Refresh toggle to ExtJs Cycle element for better UX
- other small cosmetical changes to match new Revo 2.3 manager skin
- removed Cron trigger status field (and make worker_process_active == true by default)


GoodNews 1.1.4-pl (2014-07-20)
--------------------------------------------------

- [#12] You have changes pending; are you sure you want to cancel?
- added contentblocks_replacement class to make GoodNews compatible with ContentBlocks 1.1


GoodNews 1.1.3-pl (2014-07-17)
--------------------------------------------------

- removed version_compare JS plugin and all it\'s references
- implemented a legacyMode flag for detecting older MODX versions (< 2.3)


GoodNews 1.1.2-pl (2014-07-14)
--------------------------------------------------

- fixed some installation issues (missing or wrong default settings, default container template)
- changed default bounce handling settings to more secure values


GoodNews 1.1.1-pl (2014-07-09)
--------------------------------------------------

- added SB + HB column to Subscribers grid
- fixed deleteSubscribers + updateSubscribers methods (also added groupmember and sudo check!)


GoodNews 1.1.0-pl (2014-07-09)
--------------------------------------------------

- added automatic bounce handling (parsing bounced emails and automatically handle subscriber status)
- moved all protected container settings into GoodNews system settings
- added system check for PHP Imap extension
- added auto-cleanup of susbcriptions (remove never activated accounts)
- added ID column to Subscribers grid


GoodNews 1.0.4-pl (2014-06-16)
--------------------------------------------------

- [#11] Compatibility problems with Revolution >= 2.3


GoodNews 1.0.3-pl (2014-06-10)
--------------------------------------------------

- [#10] cron.php cannot be called without the sid parameter when security key setting is disabled
- [#9] cron.worker.php throws a warning to the MODX error log (Invalid argument supplied for foreach())


GoodNews 1.0.2-pl (2014-06-08)
--------------------------------------------------

- [#7] Mailing: selection of subscribers in a category will erroneously also select the full group


GoodNews 1.0.1-pl
--------------------------------------------------

- added feature/properties to optionally send user an email after successful subscription
- added preinstalled Resource for successful subscriptions when activation isn\'t required


GoodNews 1.0.0-pl
--------------------------------------------------

- first stable release


GoodNews 1.0.0-beta3
--------------------------------------------------

- added subscribers ip tracking
- added subscription box chunk to place subscription form somewhere on site
- fixed missing security check if user is entitled to manage GoodNews container


GoodNews 1.0.0-beta2
--------------------------------------------------

- added necessary code to provide support for Revo version >= 2.3
- added Revo version detection for backwards compatibillity
- fixed a bug in multiprocessed sending (catch some rare race conditions)


GoodNews 1.0.0-beta1
--------------------------------------------------

- first public beta release',
    'copy_exclude_patterns' => 
    array (
      0 => '/^__/',
    ),
    'setup-options' => 'goodnews-1.5.0-beta7/setup-options.php',
  ),
  'manifest-vehicles' => 
  array (
    0 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modNamespace',
      'guid' => 'b1d08b0c4773901e898eaf0f482dffed',
      'native_key' => 'goodnews',
      'filename' => 'modNamespace/fe4ec3567cd723fbc92db7cb2e14d1f2.vehicle',
      'namespace' => 'goodnews',
    ),
    1 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modMenu',
      'guid' => 'a4fbd2bbbdd3648df98f2e7d27987e45',
      'native_key' => 'goodnews',
      'filename' => 'modMenu/3f1382f7a0f05ad914c2b447f68f8c46.vehicle',
      'namespace' => 'goodnews',
    ),
    2 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'bc71cfcba79783cd876f2ba747007fd3',
      'native_key' => 'goodnews.test_subject_prefix',
      'filename' => 'modSystemSetting/ba07e01e4d65e684f95fb9ea14c3c0b6.vehicle',
      'namespace' => 'goodnews',
    ),
    3 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ec5a267fc52cf143015967ad39d6f18',
      'native_key' => 'goodnews.statusemail_enabled',
      'filename' => 'modSystemSetting/2f11fd484c098c4701d326025b0ccdf1.vehicle',
      'namespace' => 'goodnews',
    ),
    4 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '7471f08dc2f43c121584b5d1ec8598f9',
      'native_key' => 'goodnews.statusemail_fromname',
      'filename' => 'modSystemSetting/dba5b293a77ee4bb2968dfb56db3ff9e.vehicle',
      'namespace' => 'goodnews',
    ),
    5 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'ef51ea07b672ab3cfcc200f82287b857',
      'native_key' => 'goodnews.statusemail_chunk',
      'filename' => 'modSystemSetting/8f553da55b968c81635602ab70215405.vehicle',
      'namespace' => 'goodnews',
    ),
    6 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4682baf5e434dddae7c84c17696c13b6',
      'native_key' => 'goodnews.auto_fix_imagesizes',
      'filename' => 'modSystemSetting/d5661393890a8721bfa480659d98bcc4.vehicle',
      'namespace' => 'goodnews',
    ),
    7 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '08f1c8d1df620cc733c0c73fa4a17e68',
      'native_key' => 'goodnews.auto_full_urls',
      'filename' => 'modSystemSetting/2f0bd60ad86b84ba35f3ef63680fe6dd.vehicle',
      'namespace' => 'goodnews',
    ),
    8 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '59e0cf0a8c261277ffdb8fbeea4a6d22',
      'native_key' => 'goodnews.auto_inline_css',
      'filename' => 'modSystemSetting/46e00594f327c56dcae1dfe408a5d398.vehicle',
      'namespace' => 'goodnews',
    ),
    9 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'f1e00c2d2aace27ab22ae0955ba82e3b',
      'native_key' => 'goodnews.auto_cleanup_subscriptions',
      'filename' => 'modSystemSetting/55dfb195f74d91861b4dcec4b5cce64f.vehicle',
      'namespace' => 'goodnews',
    ),
    10 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '75463c33a2d0ed5f615199e470ba3017',
      'native_key' => 'goodnews.auto_cleanup_subscriptions_ttl',
      'filename' => 'modSystemSetting/ae28381f0f02236541f011514cc86ae1.vehicle',
      'namespace' => 'goodnews',
    ),
    11 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => 'b7595720d7c81d2397cbf7b36a153aa9',
      'native_key' => 'goodnews.mailing_bulk_size',
      'filename' => 'modSystemSetting/4c3947e260b63fb82308b2c6d19b1d5f.vehicle',
      'namespace' => 'goodnews',
    ),
    12 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4ef7bcd2f18364c652bcf8ec2a124986',
      'native_key' => 'goodnews.worker_process_active',
      'filename' => 'modSystemSetting/447ded5c7f58833d9133a357c188f0c9.vehicle',
      'namespace' => 'goodnews',
    ),
    13 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '4fb94864390b82b5b20a7356c2a84f99',
      'native_key' => 'goodnews.worker_process_limit',
      'filename' => 'modSystemSetting/9cd700bb328736a2f90cac3d95a7a7bb.vehicle',
      'namespace' => 'goodnews',
    ),
    14 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '64f4d2366d84ac03a7ee026ef4fcd507',
      'native_key' => 'goodnews.admin_groups',
      'filename' => 'modSystemSetting/419b5317066b90c4a423dfa5693ff1b7.vehicle',
      'namespace' => 'goodnews',
    ),
    15 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '10ee81f666e4039ac31d536fd288cf99',
      'native_key' => 'goodnews.cron_security_key',
      'filename' => 'modSystemSetting/7884a7a56f2f1e7f0bace51551c39713.vehicle',
      'namespace' => 'goodnews',
    ),
    16 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '9dd551db667bef167f1689b92bdeada6',
      'native_key' => 'goodnews.default_container_template',
      'filename' => 'modSystemSetting/af3520a3f9f426c4ffec7a77e00c7779.vehicle',
      'namespace' => 'goodnews',
    ),
    17 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modSystemSetting',
      'guid' => '8b5fba28eb1d8ee41ab299f4f9c36fdb',
      'native_key' => 'goodnews.debug',
      'filename' => 'modSystemSetting/c974d42065a1f5aad14344e72fe8b0b2.vehicle',
      'namespace' => 'goodnews',
    ),
    18 => 
    array (
      'vehicle_package' => 'transport',
      'vehicle_class' => 'xPDOObjectVehicle',
      'class' => 'modCategory',
      'guid' => '0282f5ad0eb4955f7367c4967b24fdbd',
      'native_key' => 1,
      'filename' => 'modCategory/f77d8b6f6e1d0bebff65e5392768940f.vehicle',
      'namespace' => 'goodnews',
    ),
  ),
);