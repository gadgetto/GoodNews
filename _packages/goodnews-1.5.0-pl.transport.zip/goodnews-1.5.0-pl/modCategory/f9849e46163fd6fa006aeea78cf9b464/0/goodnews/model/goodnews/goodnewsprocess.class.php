<?php
/**
 * @package goodnews
 */
class GoodNewsProcess extends xPDOSimpleObject {}
?>