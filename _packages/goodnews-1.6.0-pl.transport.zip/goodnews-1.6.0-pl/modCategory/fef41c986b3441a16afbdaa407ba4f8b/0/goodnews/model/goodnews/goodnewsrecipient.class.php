<?php
/**
 * @package goodnews
 */
class GoodNewsRecipient extends xPDOSimpleObject {}
?>