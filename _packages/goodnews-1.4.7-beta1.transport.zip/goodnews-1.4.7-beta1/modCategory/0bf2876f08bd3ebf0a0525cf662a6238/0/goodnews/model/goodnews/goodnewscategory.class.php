<?php
/**
 * @package goodnews
 */
class GoodNewsCategory extends xPDOSimpleObject {}
?>