<?php
/**
 * @package goodnews
 */
class GoodNewsMailingMeta extends xPDOSimpleObject {}
?>