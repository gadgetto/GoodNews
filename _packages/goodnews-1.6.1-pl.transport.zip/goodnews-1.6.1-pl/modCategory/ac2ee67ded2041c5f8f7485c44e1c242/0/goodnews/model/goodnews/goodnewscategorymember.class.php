<?php
/**
 * @package goodnews
 */
class GoodNewsCategoryMember extends xPDOSimpleObject {}
?>