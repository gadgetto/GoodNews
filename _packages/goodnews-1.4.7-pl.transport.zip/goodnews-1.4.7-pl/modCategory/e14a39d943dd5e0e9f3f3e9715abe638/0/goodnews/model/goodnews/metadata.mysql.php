<?php

$xpdo_meta_map = array (
  'modResource' => 
  array (
    0 => 'GoodNewsResourceContainer',
    1 => 'GoodNewsResourceMailing',
  ),
  'xPDOSimpleObject' => 
  array (
    0 => 'GoodNewsMailingMeta',
    1 => 'GoodNewsRecipient',
    2 => 'GoodNewsSubscriberMeta',
    3 => 'GoodNewsSubscriberLog',
    4 => 'GoodNewsGroup',
    5 => 'GoodNewsGroupMember',
    6 => 'GoodNewsCategory',
    7 => 'GoodNewsCategoryMember',
    8 => 'GoodNewsProcess',
  ),
);