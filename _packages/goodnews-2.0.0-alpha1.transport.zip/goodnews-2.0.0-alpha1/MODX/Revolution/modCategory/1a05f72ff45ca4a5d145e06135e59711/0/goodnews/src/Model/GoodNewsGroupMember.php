<?php
namespace Bitego\GoodNews\Model;

use xPDO\xPDO;

/**
 * Class GoodNewsGroupMember
 *
 * @property integer $goodnewsgroup_id
 * @property integer $member_id
 *
 * @package Bitego\GoodNews\Model
 */
class GoodNewsGroupMember extends \xPDO\Om\xPDOSimpleObject
{
}
