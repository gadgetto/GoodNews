<?php
$xpdo_meta_map = array (
    'version' => '3.0',
    'namespace' => 'Bitego\\GoodNews\\Model',
    'namespacePrefix' => 'Bitego\\GoodNews',
    'class_map' => 
    array (
        'MODX\\Revolution\\modResource' => 
        array (
            0 => 'Bitego\\GoodNews\\Model\\GoodNewsResourceContainer',
            1 => 'Bitego\\GoodNews\\Model\\GoodNewsResourceMailing',
        ),
        'xPDO\\Om\\xPDOSimpleObject' => 
        array (
            0 => 'Bitego\\GoodNews\\Model\\GoodNewsMailingMeta',
            1 => 'Bitego\\GoodNews\\Model\\GoodNewsRecipient',
            2 => 'Bitego\\GoodNews\\Model\\GoodNewsSubscriberMeta',
            3 => 'Bitego\\GoodNews\\Model\\GoodNewsSubscriberLog',
            4 => 'Bitego\\GoodNews\\Model\\GoodNewsGroup',
            5 => 'Bitego\\GoodNews\\Model\\GoodNewsGroupMember',
            6 => 'Bitego\\GoodNews\\Model\\GoodNewsCategory',
            7 => 'Bitego\\GoodNews\\Model\\GoodNewsCategoryMember',
            8 => 'Bitego\\GoodNews\\Model\\GoodNewsProcess',
        ),
    ),
);