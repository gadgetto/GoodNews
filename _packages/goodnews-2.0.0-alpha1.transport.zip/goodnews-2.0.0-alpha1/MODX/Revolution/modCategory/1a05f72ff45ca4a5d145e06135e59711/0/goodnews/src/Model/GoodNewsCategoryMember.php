<?php
namespace Bitego\GoodNews\Model;

use xPDO\xPDO;

/**
 * Class GoodNewsCategoryMember
 *
 * @property integer $goodnewscategory_id
 * @property integer $member_id
 *
 * @package Bitego\GoodNews\Model
 */
class GoodNewsCategoryMember extends \xPDO\Om\xPDOSimpleObject
{
}
