<?php
/**
 * @package goodnews
 */
class GoodNewsSubscriberMeta extends xPDOSimpleObject {}
?>