<?php
/**
 * @package goodnews
 */
class GoodNewsGroup extends xPDOSimpleObject {}
?>