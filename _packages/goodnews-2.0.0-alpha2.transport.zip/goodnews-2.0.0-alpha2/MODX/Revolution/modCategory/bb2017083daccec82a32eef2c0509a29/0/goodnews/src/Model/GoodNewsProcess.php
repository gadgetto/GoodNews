<?php
namespace Bitego\GoodNews\Model;

use xPDO\xPDO;

/**
 * Class GoodNewsProcess
 *
 * @property string $pid
 * @property string $starttime
 *
 * @package Bitego\GoodNews\Model
 */
class GoodNewsProcess extends \xPDO\Om\xPDOSimpleObject
{
}
