<?php
namespace TijsVerkoyen\CssToInlineStyles;

/**
* CssToInlineStyles Exception class
*
* @author	Tijs Verkoyen <php-css-to-inline-styles@verkoyen.eu>
 */
class Exception extends \Exception
{
}
