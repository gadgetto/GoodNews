<?php
/**
 * @package goodnews
 */
class GoodNewsSubscriberLog extends xPDOSimpleObject {}
?>